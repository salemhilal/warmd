  <object id="emff" type="application/x-shockwave-flash" data="emff.swf?src=http://db.wrct.org/php/test/getfile2.php?date=2012-01-01-00-lo" width="150" height="40">
    <param name="movie" value="emff.swf?src=http://db.wrct.org/php/test/getfile2.php?date=2012-01-01-00-lo" />
    <param name="quality" value="high" />
  </object>

